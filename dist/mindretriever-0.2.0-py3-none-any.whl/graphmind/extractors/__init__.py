"""Extraction modules for GraphMind."""
